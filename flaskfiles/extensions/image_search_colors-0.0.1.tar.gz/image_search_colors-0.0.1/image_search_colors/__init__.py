
from .image_search_average import average_image_url
from .image_search_average import google_average

__author__ = 'Rhys Hansen'
__copyright__ = "Copyright 2017, Rhys Hansen"
__license__ = "MIT"
__date__ = "2017-1-30"
__version__ = '0.0.1'
