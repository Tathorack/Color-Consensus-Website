Python package that uses PIL and multiprocessing to extract colors from images

TODO: Write an actual readme
TODO: Switch return from list to dictionary
TODO: Build tests
TODO: Change downsampling to be optional and maintain proportions


