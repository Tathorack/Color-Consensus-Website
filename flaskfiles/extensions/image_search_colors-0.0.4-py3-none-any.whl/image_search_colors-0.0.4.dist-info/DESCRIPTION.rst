Python package that uses image_colors to extract colors from web image searches

TODO: Write an actual readme
TODO: Switch return from list to dictionary
TODO: Build tests


