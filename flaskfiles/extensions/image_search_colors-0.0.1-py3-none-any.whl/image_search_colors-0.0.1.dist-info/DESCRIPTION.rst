Python package that uses image_colors to extract colors from web image searches

TODO: Switch all print statements to logging
TODO: Write an actual readme
TODO: Switch return from list to dictionary
TODO: Better variable names
TODO: Better function docstrings
TODO: Build tests


